import SchoolPortalShell from "./school-portal-shell";

export default function Home() {
  return <SchoolPortalShell />;
}
