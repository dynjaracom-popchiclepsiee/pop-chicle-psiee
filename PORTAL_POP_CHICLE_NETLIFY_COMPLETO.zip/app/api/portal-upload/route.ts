import { and, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { portalItems, schools } from "../../../db/schema";
import { isAdminRequest, resolveSchoolId } from "../school-auth";
import { createSignedUpload, deleteFile } from "../../../lib/storage";

export const dynamic = "force-dynamic";

async function context(request: Request) {
  const schoolId = await resolveSchoolId(request);
  if (!schoolId) return null;
  const db = await getDb();
  const [school] = await db.select({ id: schools.id }).from(schools).where(eq(schools.id, schoolId)).limit(1);
  return school ? { db, school, admin: await isAdminRequest(request) } : null;
}

export async function POST(request: Request) {
  const ctx = await context(request);
  if (!ctx) return Response.json({ error: "Acesso necessário." }, { status: 401 });
  const body = await request.json() as Record<string, unknown>;
  const action = String(body.action || "");

  if (action === "init") {
    const filename = String(body.filename || "arquivo").replace(/[^a-zA-Z0-9._-]/g, "_");
    const contentType = String(body.contentType || "application/octet-stream");
    const key = `${ctx.school.id}/${crypto.randomUUID()}-${filename}`;
    const signed = await createSignedUpload(key);
    return Response.json({ key, path: signed.path, signedUrl: signed.signedUrl, token: crypto.randomUUID(), filename, contentType });
  }

  if (action === "publish") {
    const kind = String(body.kind || "");
    if (!["galeria", "material", "perfil", "trabalho", "orientacao", "recado", "depoimento"].includes(kind)) {
      return Response.json({ error: "Tipo de publicação inválido." }, { status: 400 });
    }
    if (!ctx.admin && !["recado", "depoimento"].includes(kind)) {
      return Response.json({ error: "Acesso administrativo necessário." }, { status: 403 });
    }
    const files = Array.isArray(body.files) ? body.files as Array<Record<string, unknown>> : [];
    if (!files.length || files.some((file) => !String(file.key || "").startsWith(`${ctx.school.id}/`))) {
      return Response.json({ error: "Arquivos inválidos." }, { status: 400 });
    }
    const first = files[0];
    const metadata = {
      ...first, files, folder: String(body.folder || ""), date: String(body.date || ""),
      category: String(body.category || ""), responsible: String(body.responsible || ""),
      link: String(body.link || ""), workStatus: String(body.workStatus || "Em andamento"),
      audience: String(body.audience || "Equipe escolar"), priority: String(body.priority || "Normal"),
      status: ctx.admin ? "publicado" : "pendente",
    };
    const folder = String(body.folder || "");
    if (kind === "perfil") {
      const previous = await ctx.db.select().from(portalItems)
        .where(and(eq(portalItems.schoolId, ctx.school.id), eq(portalItems.kind, "perfil")));
      for (const item of previous) {
        const old = JSON.parse(item.metadata || "{}") as { key?: string; files?: Array<{ key: string }> };
        for (const stored of old.files || (old.key ? [{ key: old.key }] : [])) await deleteFile(stored.key);
      }
      await ctx.db.delete(portalItems).where(and(eq(portalItems.schoolId, ctx.school.id), eq(portalItems.kind, "perfil")));
    }
    if (kind === "material" && folder) {
      const folders = await ctx.db.select().from(portalItems)
        .where(and(eq(portalItems.schoolId, ctx.school.id), eq(portalItems.kind, "pasta")));
      if (!folders.some((item) => item.title === folder)) {
        await ctx.db.insert(portalItems).values({ schoolId: ctx.school.id, kind: "pasta", title: folder, content: "", metadata: JSON.stringify({ status: "publicado", link: "" }), sortOrder: Date.now() });
      }
    }
    const [created] = await ctx.db.insert(portalItems).values({
      schoolId: ctx.school.id, kind, title: String(body.title || files[0].filename || "Publicação"),
      content: String(body.content || ""), metadata: JSON.stringify(metadata), sortOrder: Date.now(),
    }).returning();
    return Response.json({ item: { ...created, metadata } }, { status: 201 });
  }

  return Response.json({ error: "Ação inválida." }, { status: 400 });
}
