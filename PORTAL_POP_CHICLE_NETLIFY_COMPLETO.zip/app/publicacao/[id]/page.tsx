import type { Metadata } from "next";
import { and, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { portalItems, schools } from "../../../db/schema";

const BASE = "https://plataforma-escolar-pop-chicle.popchiclepsiee.chatgpt.site";

async function sharedPost(id: number, token: string) {
  const db = await getDb();
  const [item] = await db.select().from(portalItems).where(eq(portalItems.id, id)).limit(1);
  if (!item) return null;
  const metadata = JSON.parse(item.metadata || "{}");
  if (!token || metadata.shareToken !== token) return null;
  const [school] = await db.select({ name: schools.name }).from(schools).where(eq(schools.id, item.schoolId)).limit(1);
  let imageMeta = metadata;
  let imageFile = imageMeta.files?.find((entry: { contentType?: string }) => entry.contentType?.startsWith("image/"))
    || (imageMeta.contentType?.startsWith("image/") ? imageMeta : null);
  if (!imageFile) {
    const [profile] = await db.select().from(portalItems)
      .where(and(eq(portalItems.schoolId, item.schoolId), eq(portalItems.kind, "perfil"))).limit(1);
    if (profile) {
      imageMeta = JSON.parse(profile.metadata || "{}");
      imageFile = imageMeta.files?.find((entry: { contentType?: string }) => entry.contentType?.startsWith("image/"))
        || (imageMeta.contentType?.startsWith("image/") ? imageMeta : null);
    }
  }
  const image = imageFile?.key
    ? `${BASE}/api/share-image?id=${item.id}&token=${encodeURIComponent(token)}`
    : undefined;
  return { item, metadata, school, image };
}

export async function generateMetadata({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ token?: string }> }): Promise<Metadata> {
  const { id } = await params;
  const { token = "" } = await searchParams;
  const post = await sharedPost(Number(id), token);
  if (!post) return { title: "Publicação não encontrada" };
  const description = post.item.content?.slice(0, 180) || `Publicação de ${post.school?.name || "escola assessorada"}`;
  return {
    title: `${post.item.title} | POP CHICLÉ PSIEE`,
    description,
    openGraph: {
      title: post.item.title,
      description,
      type: "article",
      url: `${BASE}/publicacao/${id}?token=${encodeURIComponent(token)}`,
      images: post.image ? [{ url: post.image, alt: post.item.title, width: 1200, height: 630, type: "image/jpeg" }] : [],
    },
    twitter: { card: "summary_large_image", title: post.item.title, description, images: post.image ? [post.image] : [] },
  };
}

export default async function SharedPublication({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ token?: string }> }) {
  const { id } = await params;
  const { token = "" } = await searchParams;
  const post = await sharedPost(Number(id), token);
  if (!post) return <main className="shared-page"><article><h1>Publicação não encontrada</h1><a href="/">Voltar para a plataforma</a></article></main>;
  const file = post.metadata.files?.[0] || post.metadata;
  const media = file.key && file.token ? `${BASE}/api/portal-files?id=${post.item.id}&index=0&token=${encodeURIComponent(file.token)}` : null;
  return <main className="shared-page"><article><header><b>POP CHICLÉ PSIEE</b><span>{post.school?.name}</span></header>{media && file.contentType?.startsWith("image/") ? <img src={media} alt={post.item.title} /> : media && file.contentType?.startsWith("video/") ? <video src={`${media}#t=0.001`} controls playsInline preload="auto" /> : null}<div><small>PUBLICAÇÃO DA ESCOLA ASSESSORADA</small><h1>{post.item.title}</h1><p>{post.item.content}</p><a href="/">Acessar a plataforma</a></div></article></main>;
}
