import { createClient } from "@supabase/supabase-js";

export const STORAGE_BUCKET = "school-files";

function admin() {
  const url = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("Supabase não configurado.");
  return createClient(url, key, { auth: { persistSession: false } });
}

export async function createSignedUpload(path: string) {
  const { data, error } = await admin().storage.from(STORAGE_BUCKET).createSignedUploadUrl(path);
  if (error) throw error;
  return data;
}

export async function uploadFile(path: string, data: ArrayBuffer, contentType: string) {
  const { error } = await admin().storage.from(STORAGE_BUCKET).upload(path, data, {
    contentType,
    upsert: false,
  });
  if (error) throw error;
}

export async function downloadFile(path: string) {
  const { data, error } = await admin().storage.from(STORAGE_BUCKET).download(path);
  if (error || !data) return null;
  return data;
}

export async function deleteFile(path: string) {
  const { error } = await admin().storage.from(STORAGE_BUCKET).remove([path]);
  if (error) throw error;
}
