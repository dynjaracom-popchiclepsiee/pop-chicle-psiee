import { eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { portalSettings } from "../../../db/schema";
import { isAdminRequest } from "../school-auth";

export const dynamic = "force-dynamic";

export const defaults = {
  brandName: "POP CHICLÉ PSIEE",
  welcomeTitle: "Nossa escola em movimento.",
  welcomeText: "Agenda, trabalhos, registros, materiais e comunicação em um espaço exclusivo.",
  assessorName: "Dynjara Costa",
  assessorTitle: "Assessoria Pedagógica Especializada",
  primary: "#5b76e8",
  pink: "#ff4f9b",
  yellow: "#ffd84a",
  background: "#eef1f8",
};

export async function GET() {
  const db = await getDb();
  const rows = await db.select().from(portalSettings);
  return Response.json({ settings: { ...defaults, ...Object.fromEntries(rows.map((row) => [row.key, row.value])) } });
}

export async function PATCH(request: Request) {
  if (!(await isAdminRequest(request))) return Response.json({ error: "Acesso administrativo necessário." }, { status: 403 });
  const body = await request.json() as Record<string, unknown>;
  const db = await getDb();
  const allowed = new Set(Object.keys(defaults));
  for (const [key, raw] of Object.entries(body)) {
    if (!allowed.has(key) || typeof raw !== "string") continue;
    const value = raw.trim().slice(0, 1000);
    await db.insert(portalSettings).values({ key, value }).onConflictDoUpdate({
      target: portalSettings.key, set: { value, updatedAt: new Date().toISOString() },
    });
  }
  return Response.json({ ok: true });
}
