import { and, desc, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { portalItems, schools } from "../../../db/schema";
import { isAdminRequest, readCookie, resolveSchoolId, SESSION_COOKIE } from "../school-auth";

export const dynamic = "force-dynamic";

const ADMIN_KINDS = new Set(["agenda", "trabalho", "orientacao", "depoimento", "pasta", "material", "galeria"]);

async function context(request: Request) {
  const schoolId = await resolveSchoolId(request);
  if (!schoolId) return null;
  const db = await getDb();
  const [school] = await db.select({ id: schools.id, name: schools.name }).from(schools).where(eq(schools.id, schoolId)).limit(1);
  return school ? { db, school, admin: await isAdminRequest(request) } : null;
}

export async function GET(request: Request) {
  const ctx = await context(request);
  if (!ctx) return Response.json({ error: "Acesso da escola necessário." }, { status: 401 });
  const rows = await ctx.db
    .select()
    .from(portalItems)
    .where(eq(portalItems.schoolId, ctx.school.id))
    .orderBy(desc(portalItems.createdAt));
  const parsed = rows.map((row) => ({ ...row, metadata: JSON.parse(row.metadata || "{}") }));
  const requestedActor = new URL(request.url).searchParams.get("actor")?.slice(0, 80);
  const actor = ctx.admin ? "admin" : requestedActor || readCookie(request, SESSION_COOKIE);
  const likes = parsed.filter((item) => item.kind === "curtida");
  const comments = parsed.filter((item) => item.kind === "comentario");
  const content = parsed.filter((item) => !["curtida", "comentario"].includes(item.kind));
  for (const item of content) {
    if (!item.metadata.shareToken && !["config", "perfil"].includes(item.kind)) {
      item.metadata.shareToken = crypto.randomUUID();
      await ctx.db.update(portalItems).set({ metadata: JSON.stringify(item.metadata) })
        .where(and(eq(portalItems.id, item.id), eq(portalItems.schoolId, ctx.school.id)));
    }
  }
  return Response.json({
    school: ctx.school,
    admin: ctx.admin,
    items: content.map((item) => ({
      ...item,
      likes: likes.filter((like) => Number(like.metadata.parentId) === item.id).length,
      liked: likes.some((like) => Number(like.metadata.parentId) === item.id && like.metadata.actor === actor),
      comments: comments
        .filter((comment) => Number(comment.metadata.parentId) === item.id)
        .map((comment) => ({ id: comment.id, author: comment.title, content: comment.content, createdAt: comment.createdAt })),
    })),
  });
}

export async function POST(request: Request) {
  const ctx = await context(request);
  if (!ctx) return Response.json({ error: "Acesso da escola necessário." }, { status: 401 });
  const body = (await request.json()) as { action?: string; parentId?: number; actor?: string; kind?: string; title?: string; content?: string; metadata?: unknown };
  if (body.action === "toggle-like" && body.parentId) {
    const [parent] = await ctx.db.select({ id: portalItems.id }).from(portalItems)
      .where(and(eq(portalItems.id, body.parentId), eq(portalItems.schoolId, ctx.school.id))).limit(1);
    if (!parent) return Response.json({ error: "Publicação não encontrada." }, { status: 404 });
    const actor = ctx.admin ? "admin" : body.actor?.trim().slice(0, 80) || readCookie(request, SESSION_COOKIE);
    const likes = await ctx.db.select().from(portalItems)
      .where(and(eq(portalItems.schoolId, ctx.school.id), eq(portalItems.kind, "curtida")));
    const existing = likes.find((like) => {
      const metadata = JSON.parse(like.metadata || "{}");
      return Number(metadata.parentId) === body.parentId && metadata.actor === actor;
    });
    if (existing) {
      await ctx.db.delete(portalItems).where(eq(portalItems.id, existing.id));
      return Response.json({ liked: false });
    }
    await ctx.db.insert(portalItems).values({
      schoolId: ctx.school.id, kind: "curtida", title: "Curtida", content: "",
      metadata: JSON.stringify({ parentId: body.parentId, actor }), sortOrder: Date.now(),
    });
    return Response.json({ liked: true });
  }
  const kind = body.kind?.trim() ?? "";
  const title = body.title?.trim() ?? "";
  if (!title || (!ADMIN_KINDS.has(kind) && !["recado", "comentario"].includes(kind))) {
    return Response.json({ error: "Preencha os dados da publicação." }, { status: 400 });
  }
  if (!ctx.admin && !["recado", "depoimento", "comentario"].includes(kind)) {
    return Response.json({ error: "Somente a assessoria pode publicar este conteúdo." }, { status: 403 });
  }
  const metadata = {
    ...(typeof body.metadata === "object" && body.metadata ? body.metadata : {}),
    status: kind === "comentario" ? "publicado" : ctx.admin ? "publicado" : "pendente",
  };
  const [created] = await ctx.db
    .insert(portalItems)
    .values({
      schoolId: ctx.school.id,
      kind,
      title,
      content: body.content?.trim() ?? "",
      metadata: JSON.stringify(metadata),
      sortOrder: Date.now(),
    })
    .returning();
  return Response.json({ item: { ...created, metadata } }, { status: 201 });
}

export async function PATCH(request: Request) {
  const ctx = await context(request);
  if (!ctx?.admin) return Response.json({ error: "Acesso administrativo necessário." }, { status: 403 });
  const body = (await request.json()) as { id?: number; title?: string; content?: string; metadata?: unknown };
  if (!body.id) return Response.json({ error: "Publicação não informada." }, { status: 400 });
  const [current] = await ctx.db
    .select()
    .from(portalItems)
    .where(and(eq(portalItems.id, body.id), eq(portalItems.schoolId, ctx.school.id)))
    .limit(1);
  if (!current) return Response.json({ error: "Publicação não encontrada." }, { status: 404 });
  const metadata = {
    ...JSON.parse(current.metadata || "{}"),
    ...(typeof body.metadata === "object" && body.metadata ? body.metadata : {}),
  };
  await ctx.db
    .update(portalItems)
    .set({
      title: body.title?.trim() || current.title,
      content: body.content === undefined ? current.content : body.content.trim(),
      metadata: JSON.stringify(metadata),
      updatedAt: new Date().toISOString(),
    })
    .where(and(eq(portalItems.id, body.id), eq(portalItems.schoolId, ctx.school.id)));
  return Response.json({ ok: true });
}

export async function DELETE(request: Request) {
  const ctx = await context(request);
  if (!ctx?.admin) return Response.json({ error: "Acesso administrativo necessário." }, { status: 403 });
  const id = Number(new URL(request.url).searchParams.get("id"));
  if (!id) return Response.json({ error: "Publicação não informada." }, { status: 400 });
  await ctx.db.delete(portalItems).where(and(eq(portalItems.id, id), eq(portalItems.schoolId, ctx.school.id)));
  return Response.json({ ok: true });
}
