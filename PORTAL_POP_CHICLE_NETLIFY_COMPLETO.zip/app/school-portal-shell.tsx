"use client";

import { ChangeEvent, CSSProperties, FormEvent, useCallback, useEffect, useMemo, useRef, useState } from "react";

type School = { id: string; name: string; code?: string | null };
type Access =
  | { role: "loading" }
  | { role: "guest" }
  | { role: "admin"; schools: School[] }
  | { role: "school"; school: School };
type StoredFile = { key: string; token: string; filename: string; contentType: string; size?: number };
type Metadata = { status?: string; date?: string; folder?: string; role?: string; filename?: string; contentType?: string; link?: string; token?: string; key?: string; files?: StoredFile[]; category?: string; responsible?: string; workStatus?: string; audience?: string; priority?: string; shareToken?: string };
type PortalComment = { id: number; author: string; content: string; createdAt: string };
type PortalItem = { id: number; kind: string; title: string; content: string; metadata: Metadata; createdAt: string; likes?: number; liked?: boolean; comments?: PortalComment[] };
type CommentHandler = (item: PortalItem, content: string, author: string) => void;
type Section = "inicio" | "agenda" | "calendario" | "trabalhos" | "galeria" | "materiais" | "comunicacao";
type Settings = { brandName: string; welcomeTitle: string; welcomeText: string; assessorName: string; assessorTitle: string; primary: string; pink: string; yellow: string; background: string };
const defaultSettings: Settings = { brandName: "POP CHICLÉ PSIEE", welcomeTitle: "Nossa escola em movimento.", welcomeText: "Agenda, trabalhos, registros, materiais e comunicação em um espaço exclusivo.", assessorName: "Dynjara Costa", assessorTitle: "Assessoria Pedagógica Especializada", primary: "#5b76e8", pink: "#ff4f9b", yellow: "#ffd84a", background: "#eef1f8" };

const sections: { id: Section; label: string; icon: string }[] = [
  { id: "inicio", label: "Início", icon: "⌂" },
  { id: "agenda", label: "Agenda", icon: "▣" },
  { id: "calendario", label: "Calendário", icon: "□" },
  { id: "trabalhos", label: "Trabalhos", icon: "✦" },
  { id: "galeria", label: "Galeria", icon: "▧" },
  { id: "materiais", label: "Materiais", icon: "▰" },
  { id: "comunicacao", label: "Comunicação", icon: "✉" },
];

function fileUrl(item: PortalItem, query: string, index = 0) {
  const separator = query ? "&" : "?";
  const stored = item.metadata.files?.[index];
  const tokenValue = stored?.token || item.metadata.token;
  const token = tokenValue ? `&token=${encodeURIComponent(tokenValue)}` : "";
  return `/api/portal-files${query}${separator}id=${item.id}&index=${index}${token}`;
}

function videoFileUrl(item: PortalItem, query: string, index = 0) {
  return `${fileUrl(item, query, index)}#t=0.001`;
}

function likeActor() {
  let actor = window.sessionStorage.getItem("pop_like_actor");
  if (!actor) {
    actor = crypto.randomUUID();
    window.sessionStorage.setItem("pop_like_actor", actor);
  }
  return actor;
}

async function shareItem(item: PortalItem) {
  const url = `${window.location.origin}/publicacao/${item.id}?token=${encodeURIComponent(item.metadata.shareToken || "")}&compartilhamento=${Date.now()}`;
  const data = { title: item.title, text: item.content || item.title, url };
  if (navigator.share) await navigator.share(data).catch(() => undefined);
  else {
    await navigator.clipboard.writeText(url);
    window.alert("Link da publicação copiado.");
  }
}

export default function SchoolPortalShell() {
  const [access, setAccess] = useState<Access>({ role: "loading" });
  const [selected, setSelected] = useState<School | null>(null);
  const [section, setSection] = useState<Section>("inicio");
  const [items, setItems] = useState<PortalItem[]>([]);
  const [code, setCode] = useState("");
  const [schoolName, setSchoolName] = useState("");
  const [createdCode, setCreatedCode] = useState("");
  const [codeSchoolId, setCodeSchoolId] = useState("");
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");
  const [composer, setComposer] = useState(false);
  const [editing, setEditing] = useState<PortalItem | null>(null);
  const [mobileNav, setMobileNav] = useState(false);
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [schoolEditor, setSchoolEditor] = useState(false);

  const school = selected ?? (access.role === "school" ? access.school : null);
  const admin = access.role === "admin";
  const query = admin && school ? `?schoolId=${encodeURIComponent(school.id)}` : "";

  const refreshAccess = useCallback(async () => {
    const response = await fetch("/api/access", { cache: "no-store" });
    setAccess(response.ok ? await response.json() : { role: "guest" });
  }, []);

  const loadItems = useCallback(async (target: School, role: Access["role"]) => {
    const params = new URLSearchParams();
    if (role === "admin") params.set("schoolId", target.id);
    else params.set("actor", likeActor());
    const suffix = params.size ? `?${params.toString()}` : "";
    for (let attempt = 0; attempt < 3; attempt++) {
      const response = await fetch(`/api/portal-items${suffix}`, { cache: "no-store" });
      const data = await response.json();
      if (response.ok) {
        setItems(data.items || []);
        return;
      }
      if (response.status !== 401 || attempt === 2) throw new Error(data.error || "Não foi possível abrir o portal.");
      await new Promise((resolve) => window.setTimeout(resolve, 250));
    }
  }, []);

  useEffect(() => {
    const activeTab = window.sessionStorage.getItem("pop_active_portal") === "1";
    fetch(activeTab ? "/api/access" : "/api/access?entry=1", { cache: "no-store" })
      .then((response) => response.ok ? response.json() : { role: "guest" })
      .then(async (nextAccess: Access) => {
        setAccess(nextAccess);
        const savedSection = window.sessionStorage.getItem("pop_portal_section");
        if (sections.some((item) => item.id === savedSection)) setSection(savedSection as Section);
        if (activeTab && nextAccess.role === "school") {
          setSelected(nextAccess.school);
          try {
            await loadItems(nextAccess.school, "school");
          } catch (reason) {
            setError(reason instanceof Error ? reason.message : "Não foi possível carregar os conteúdos.");
          }
        } else if (activeTab && nextAccess.role === "admin") {
          const savedSchoolId = window.sessionStorage.getItem("pop_selected_school");
          const savedSchool = nextAccess.schools.find((item) => item.id === savedSchoolId);
          if (savedSchool) {
            setSelected(savedSchool);
            loadItems(savedSchool, "admin").catch((reason) => setError(reason.message));
          }
        }
      })
      .catch(() => setAccess({ role: "guest" }));
    fetch("/api/settings", { cache: "no-store" }).then((response) => response.json()).then((data) => setSettings(data.settings || defaultSettings)).catch(() => undefined);
  }, [loadItems]);

  async function adminLogin(username: string, password: string) {
    const response = await fetch("/api/access", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "admin-login", username, password }) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Não foi possível entrar.");
    window.sessionStorage.setItem("pop_active_portal", "1");
    await refreshAccess();
  }

  async function saveSettings(next: Settings) {
    const response = await fetch("/api/settings", { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify(next) });
    if (!response.ok) return setStatus("Não foi possível salvar a aparência.");
    setSettings(next); setSettingsOpen(false); setStatus("Aparência e textos atualizados ✓");
    window.setTimeout(() => setStatus(""), 2200);
  }

  useEffect(() => {
    if (selected) window.sessionStorage.setItem("pop_portal_section", section);
  }, [section, selected]);

  const publicItems = useMemo(
    () => items.filter((item) => admin || item.metadata.status !== "pendente"),
    [admin, items],
  );

  const byKind = useCallback((kind: string) => publicItems.filter((item) => item.kind === kind), [publicItems]);

  async function login(event: FormEvent) {
    event.preventDefault();
    setError("");
    const response = await fetch("/api/access", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "login", code }),
    });
    const data = await response.json();
    if (!response.ok) return setError(data.error || "Código inválido.");
    window.sessionStorage.setItem("pop_active_portal", "1");
    setAccess({ role: "school", school: data.school });
    setSelected(data.school);
    try {
      await loadItems(data.school, "school");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Não foi possível carregar os conteúdos.");
    }
    setCode("");
  }

  async function createSchool(event: FormEvent) {
    event.preventDefault();
    if (!schoolName.trim()) return;
    const response = await fetch("/api/access", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "create-school", name: schoolName }),
    });
    const data = await response.json();
    if (!response.ok) return setError(data.error || "Não foi possível criar a escola.");
    setCreatedCode(data.code);
    setCodeSchoolId(data.school.id);
    setSchoolName("");
    await refreshAccess();
  }

  async function resetCode(target: School) {
    const response = await fetch("/api/access", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "reset-code", schoolId: target.id }),
    });
    const data = await response.json();
    if (response.ok) {
      setCreatedCode(data.code);
      setCodeSchoolId(target.id);
      await refreshAccess();
    }
  }

  async function openSchool(target: School) {
    setSelected(target);
    setSection("inicio");
    window.sessionStorage.setItem("pop_selected_school", target.id);
    window.sessionStorage.setItem("pop_portal_section", "inicio");
    setStatus("Abrindo o portal...");
    try {
      await loadItems(target, access.role);
      setStatus("");
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Não foi possível abrir o portal.");
      setSelected(null);
    }
  }

  async function logout() {
    await fetch("/api/access", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "logout" }),
    });
    setSelected(null);
    setItems([]);
    setAccess({ role: "guest" });
    window.sessionStorage.removeItem("pop_active_portal");
    window.sessionStorage.removeItem("pop_selected_school");
    window.sessionStorage.removeItem("pop_portal_section");
  }

  async function saveTextItem(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!school) return;
    const data = new FormData(event.currentTarget);
    const payload = {
      id: editing?.id,
      kind: String(data.get("kind") || ""),
      title: String(data.get("title") || ""),
      content: String(data.get("content") || ""),
      metadata: {
        date: String(data.get("date") || ""),
        role: String(data.get("role") || ""),
        link: String(data.get("link") || ""),
        audience: String(data.get("audience") || ""),
        priority: String(data.get("priority") || ""),
        status: String(data.get("status") || (admin ? "publicado" : "pendente")),
      },
    };
    setStatus("Salvando...");
    const response = await fetch(`/api/portal-items${query}`, {
      method: editing ? "PATCH" : "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
    });
    const result = await response.json();
    if (!response.ok) return setStatus(result.error || "Não foi possível salvar.");
    await loadItems(school, access.role);
    setComposer(false);
    setEditing(null);
    setStatus(admin ? "Publicação salva ✓" : "Recado enviado para aprovação ✓");
    window.setTimeout(() => setStatus(""), 2200);
  }

  async function saveFile(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!school) return;
    await uploadFormData(new FormData(event.currentTarget));
  }

  async function uploadFormData(body: FormData, successMessage = "Arquivo publicado ✓", closeComposer = true) {
    if (!school) return;
    const uploadFiles = [...body.getAll("files"), body.get("file")].filter((entry): entry is File => entry instanceof File && entry.size > 0);
    if (!uploadFiles.length) return setStatus("Selecione pelo menos um arquivo.");
    if (uploadFiles.length > 10) return setStatus("Envie no máximo 10 arquivos por publicação.");
    if (uploadFiles.reduce((total, file) => total + file.size, 0) > 1024 * 1024 * 1024) return setStatus("A publicação pode ter até 1 GB no total.");
    setStatus("Enviando arquivo...");
    try {
      if (uploadFiles.length) {
        const files: StoredFile[] = [];
        for (let fileIndex = 0; fileIndex < uploadFiles.length; fileIndex++) {
          const file = uploadFiles[fileIndex];
          setStatus(`Enviando ${file.name} (${fileIndex + 1}/${uploadFiles.length})...`);
          const initResponse = await fetch(`/api/portal-upload${query}`, {
            method: "POST", headers: { "content-type": "application/json" },
            body: JSON.stringify({ action: "init", filename: file.name, contentType: file.type || "application/octet-stream" }),
          });
          const init = await initResponse.json();
          if (!initResponse.ok) throw new Error(init.error || "Não foi possível iniciar o vídeo.");
          const uploadResponse = await fetch(init.signedUrl, {
            method: "PUT",
            headers: { "content-type": file.type || "application/octet-stream", "x-upsert": "false" },
            body: file,
          });
          if (!uploadResponse.ok) throw new Error(`O armazenamento recusou ${file.name}. Confira o limite configurado no Supabase.`);
          setStatus(`Enviando ${file.name}: 100%`);
          files.push({ key: init.key, token: init.token, filename: file.name, contentType: file.type || "application/octet-stream", size: file.size });
        }
        const publishPayload: Record<string, unknown> = { action: "publish", files };
        for (const key of ["kind", "title", "content", "folder", "date", "category", "responsible", "link", "workStatus", "audience", "priority"]) {
          publishPayload[key] = String(body.get(key) || "");
        }
        const publishResponse = await fetch(`/api/portal-upload${query}`, {
          method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(publishPayload),
        });
        const published = await publishResponse.json();
        if (!publishResponse.ok) throw new Error(published.error || "Não foi possível publicar o vídeo.");
        await loadItems(school, access.role);
        if (closeComposer) setComposer(false);
        setStatus(successMessage);
        window.setTimeout(() => setStatus(""), 2200);
        return;
      }
    } catch (reason) {
      setStatus(`O envio não foi concluído: ${reason instanceof Error ? reason.message : "erro de conexão"}.`);
    }
  }

  async function saveWork(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!school) return;
    const body = new FormData(event.currentTarget);
    const files = body.getAll("files").filter((entry) => entry instanceof File && entry.size > 0);
    setStatus(editing ? "Salvando alterações..." : "Publicando trabalho...");
    let response: Response;
    if (editing) {
      response = await fetch(`/api/portal-items${query}`, {
        method: "PATCH", headers: { "content-type": "application/json" },
        body: JSON.stringify({
          id: editing.id, title: body.get("title"), content: body.get("content"),
          metadata: { date: body.get("date"), category: body.get("category"), responsible: body.get("responsible"), link: body.get("link"), workStatus: body.get("workStatus") },
        }),
      });
    } else if (files.length > 0) {
      await uploadFormData(body, "Trabalho salvo ✓");
      return;
    } else {
      response = await fetch(`/api/portal-items${query}`, {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({
          kind: "trabalho", title: body.get("title"), content: body.get("content"),
          metadata: { date: body.get("date"), category: body.get("category"), responsible: body.get("responsible"), link: body.get("link"), workStatus: body.get("workStatus") },
        }),
      });
    }
    const result = await response.json();
    if (!response.ok) return setStatus(result.error || "Não foi possível salvar o trabalho.");
    await loadItems(school, access.role);
    setComposer(false); setEditing(null); setStatus("Trabalho salvo ✓");
    window.setTimeout(() => setStatus(""), 2200);
  }

  async function saveCommunication(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!school) return;
    const body = new FormData(event.currentTarget);
    const files = body.getAll("files").filter((entry) => entry instanceof File && entry.size > 0);
    if (files.length) return saveFile(event);
    return saveTextItem(event);
  }

  async function updateSchoolProfile(name: string, subtitle: string) {
    if (!school) return;
    const response = await fetch("/api/access", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "update-school", schoolId: school.id, name, subtitle }) });
    const data = await response.json();
    if (!response.ok) return setStatus(data.error || "Não foi possível editar a escola.");
    setSelected(data.school);
    await loadItems(data.school, access.role);
    setSchoolEditor(false); setStatus("Perfil da escola atualizado ✓");
  }

  async function removeItem(item: PortalItem) {
    if (!school || !window.confirm(`Excluir “${item.title}”?`)) return;
    const response = await fetch(`/api/portal-items${query}${query ? "&" : "?"}id=${item.id}`, { method: "DELETE" });
    if (response.ok) await loadItems(school, access.role);
  }

  async function changeSchoolPhoto(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file || !school) return;
    const body = new FormData();
    body.set("kind", "perfil");
    body.set("title", `Foto de ${school.name}`);
    body.set("file", file);
    setStatus("Enviando a foto da escola...");
    try {
      await uploadFormData(body, "Foto da escola atualizada ✓", false);
      event.target.value = "";
    } catch {
      setStatus("A foto não foi enviada. Use JPG ou PNG com até 20 MB.");
    }
  }

  async function approve(item: PortalItem) {
    if (!school) return;
    await fetch(`/api/portal-items${query}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id: item.id, metadata: { status: "publicado" } }),
    });
    await loadItems(school, access.role);
  }

  async function toggleLike(item: PortalItem) {
    if (!school) return;
    await fetch(`/api/portal-items${query}`, {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "toggle-like", parentId: item.id, actor: admin ? "admin" : likeActor() }),
    });
    await loadItems(school, access.role);
  }

  async function addComment(item: PortalItem, content: string, author: string) {
    if (!school || !content.trim() || !author.trim()) return;
    const response = await fetch(`/api/portal-items${query}`, {
      method: "POST", headers: { "content-type": "application/json" },
      body: JSON.stringify({ kind: "comentario", title: author.trim(), content, metadata: { parentId: item.id } }),
    });
    if (response.ok) await loadItems(school, access.role);
  }

  if (access.role === "loading") return <Loading />;
  const themeStyle = { "--blue": settings.primary, "--pink": settings.pink, "--yellow": settings.yellow, "--bg": settings.background } as CSSProperties;
  if (access.role === "guest") return <div style={themeStyle}><Login code={code} setCode={setCode} error={error} settings={settings} onSubmit={login} onAdminLogin={adminLogin} /></div>;
  if (admin && !selected) {
    return (
      <div style={themeStyle}><AdminSchools
        access={access}
        schoolName={schoolName}
        setSchoolName={setSchoolName}
        createdCode={createdCode}
        codeSchoolId={codeSchoolId}
        onCreate={createSchool}
        onOpen={openSchool}
        onReset={resetCode}
        onShowCode={(target) => { setCodeSchoolId(target.id); setCreatedCode(target.code || ""); }}
        settings={settings}
        onEditSettings={() => setSettingsOpen(true)}
        onLogout={logout}
      />{settingsOpen ? <SettingsEditor settings={settings} onClose={() => setSettingsOpen(false)} onSave={saveSettings} /> : null}</div>
    );
  }

  return (
    <main className="orkut-shell" style={themeStyle}>
      <header className="orkut-topbar">
        <button className="mobile-menu" onClick={() => setMobileNav(!mobileNav)} aria-label="Abrir menu">☰</button>
        <div className="brand-word">{settings.brandName}</div>
        <div className="top-school"><strong>{school?.name}</strong><span>{admin ? "modo administradora" : "portal exclusivo da escola"}</span></div>
        <div className="top-actions">
          {admin ? <button onClick={() => { setSelected(null); setItems([]); window.sessionStorage.removeItem("pop_selected_school"); window.sessionStorage.removeItem("pop_portal_section"); }}>Trocar de escola</button> : null}
          {admin ? <button onClick={() => setSettingsOpen(true)}>✎ Editar portal</button> : null}
          <button className="top-logout" onClick={logout}>Sair</button>
        </div>
      </header>

      <div className="orkut-layout">
        <aside className={`left-column${mobileNav ? " open" : ""}`}>
          <div className="school-profile">
            <div className="school-avatar">{byKind("perfil")[0] ? <img src={fileUrl(byKind("perfil")[0], query)} alt={`Foto de ${school?.name}`} /> : <span>🏫</span>}</div>
            <h1>{school?.name}</h1>
            <p>{byKind("config")[0]?.content || "Escola assessorada pela POP CHICLÉ PSIEE"}</p>
            {admin ? <><label className="change-photo">Trocar foto<input type="file" accept="image/*" onChange={changeSchoolPhoto} /></label>{byKind("perfil")[0] ? <button className="delete-photo" onClick={() => removeItem(byKind("perfil")[0])}>Excluir foto</button> : null}</> : null}
            {admin ? <button className="edit-school-profile" onClick={() => setSchoolEditor(true)}>Editar nome e descrição</button> : null}
          </div>
          <nav className="orkut-nav">
            {sections.map((item) => (
              <button key={item.id} className={section === item.id ? "active" : ""} onClick={() => { setSection(item.id); setMobileNav(false); }}>
                <span>{item.icon}</span>{item.label}
              </button>
            ))}
            <button className="mobile-logout" onClick={logout}><span>↪</span>Sair</button>
          </nav>
          <div className="access-note"><b>🔒 Espaço exclusivo</b><p>Os conteúdos desta escola não aparecem nos portais das demais.</p></div>
        </aside>

        <section className="center-column">
          <SectionHeader section={section} admin={admin} onAdd={() => { setEditing(null); setComposer(true); }} />
          {section === "inicio" ? <Home school={school} items={publicItems} admin={admin} onNavigate={setSection} onLike={toggleLike} onComment={addComment} onEdit={(item) => { setSection(item.kind === "trabalho" ? "trabalhos" : item.kind === "galeria" ? "galeria" : item.kind === "agenda" ? "agenda" : "comunicacao"); setEditing(item); setComposer(true); }} onDelete={removeItem} /> : null}
          {section === "agenda" ? <Agenda items={byKind("agenda")} admin={admin} onEdit={(item) => { setEditing(item); setComposer(true); }} onDelete={removeItem} /> : null}
          {section === "calendario" ? <Calendar items={byKind("agenda")} /> : null}
          {section === "trabalhos" ? <Feed items={byKind("trabalho")} empty="Nenhum trabalho publicado ainda." admin={admin} onEdit={(item) => { setEditing(item); setComposer(true); }} onDelete={removeItem} onLike={toggleLike} onComment={addComment} /> : null}
          {section === "galeria" ? <Gallery items={byKind("galeria")} admin={admin} onEdit={(item) => { setEditing(item); setComposer(true); }} onDelete={removeItem} query={query} onLike={toggleLike} onComment={addComment} /> : null}
          {section === "materiais" ? <Materials folders={byKind("pasta")} items={byKind("material")} admin={admin} onEdit={(item) => { setEditing(item); setComposer(true); }} onDelete={removeItem} query={query} /> : null}
          {section === "comunicacao" ? <Communication items={[...byKind("orientacao"), ...byKind("recado"), ...byKind("depoimento")].sort((a, b) => b.id - a.id)} admin={admin} onApprove={approve} onDelete={removeItem} onMessage={() => { setEditing(null); setComposer(true); }} onLike={toggleLike} onComment={addComment} /> : null}
        </section>

        <aside className="right-column">
          <div className="advisor-card">
            <div className="advisor-avatar">DC</div>
            <h2>{settings.assessorName}</h2>
            <p>{settings.assessorTitle}</p>
            <span className="online">● acompanhamento ativo</span>
          </div>
          <div className="summary-card">
            <h3>Movimento da escola</h3>
            <div><b>{byKind("agenda").length}</b><span>compromissos</span></div>
            <div><b>{byKind("trabalho").length}</b><span>trabalhos</span></div>
            <div><b>{byKind("material").length}</b><span>materiais</span></div>
          </div>
          <div className="method-card"><b>Conhecimentos que grudam.</b><p>Estratégias que flexionam.</p></div>
        </aside>
      </div>

      {composer && school ? (
        <Composer
          section={section}
          admin={admin}
          editing={editing}
          onClose={() => { setComposer(false); setEditing(null); }}
          onSaveText={saveTextItem}
          onSaveFile={saveFile}
          onSaveWork={saveWork}
          onSaveCommunication={saveCommunication}
        />
      ) : null}
      {status ? <div className="portal-toast">{status}</div> : null}
      {settingsOpen ? <SettingsEditor settings={settings} onClose={() => setSettingsOpen(false)} onSave={saveSettings} /> : null}
      {schoolEditor && school ? <SchoolEditor school={school} subtitle={byKind("config")[0]?.content || "Escola assessorada pela POP CHICLÉ PSIEE"} onClose={() => setSchoolEditor(false)} onSave={updateSchoolProfile} /> : null}
    </main>
  );
}

function Loading() {
  return <main className="auth-page"><div className="auth-card"><b>POP CHICLÉ PSIEE</b><p>Abrindo a plataforma...</p></div></main>;
}

function Login({ code, setCode, error, settings, onSubmit, onAdminLogin }: { code: string; setCode: (value: string) => void; error: string; settings: Settings; onSubmit: (event: FormEvent) => void; onAdminLogin: (username: string, password: string) => Promise<void> }) {
  const [adminMode, setAdminMode] = useState(false);
  const [adminError, setAdminError] = useState("");
  return (
    <main className="auth-page">
      <section className="auth-card">
        <div className="auth-logo"><b>{settings.brandName}</b></div>
        <p className="eyebrow">PORTAL DA ESCOLA ASSESSORADA</p>
        <h1>{settings.welcomeTitle}</h1>
        <p>{settings.welcomeText}</p>
        {!adminMode ? <form onSubmit={onSubmit}>
          <label>Código exclusivo da escola<input value={code} onChange={(event) => setCode(event.target.value.toUpperCase())} placeholder="POP-XXXXXXX" /></label>
          <button>Entrar no portal</button>
        </form> : <form onSubmit={async (event) => { event.preventDefault(); const data = new FormData(event.currentTarget); try { await onAdminLogin(String(data.get("username")), String(data.get("password"))); } catch (reason) { setAdminError(reason instanceof Error ? reason.message : "Não foi possível entrar."); } }}>
          <label>Usuário administrativo<input name="username" autoComplete="username" required /></label>
          <label>Senha<input name="password" type="password" autoComplete="current-password" required /></label>
          <button>Entrar como administradora</button>
        </form>}
        {error || adminError ? <p className="form-error">{adminError || error}</p> : null}
        <button className="switch-login" onClick={() => { setAdminMode(!adminMode); setAdminError(""); }}>{adminMode ? "Voltar ao acesso da escola" : "Acesso da administradora"}</button>
      </section>
    </main>
  );
}

function AdminSchools({ access, schoolName, setSchoolName, createdCode, codeSchoolId, onCreate, onOpen, onReset, onShowCode, settings, onEditSettings, onLogout }: {
  access: Extract<Access, { role: "admin" }>; schoolName: string; setSchoolName: (value: string) => void; createdCode: string; codeSchoolId: string;
  onCreate: (event: FormEvent) => void; onOpen: (school: School) => void; onReset: (school: School) => void; onShowCode: (school: School) => void; settings: Settings; onEditSettings: () => void; onLogout: () => void;
}) {
  const codeSchool = access.schools.find((school) => school.id === codeSchoolId);
  return (
    <main className="admin-home">
      <header><div className="brand-word">{settings.brandName}</div><div className="admin-header-actions"><div><strong>{settings.assessorName}</strong><span>Administração</span></div><button onClick={onLogout}>Sair</button></div></header>
      <div className="admin-orkut-layout"><aside className="admin-profile"><div className="advisor-avatar">DC</div><h2>{settings.assessorName}</h2><p>{settings.assessorTitle}</p><button onClick={onEditSettings}>✎ Editar aparência e textos</button><nav><b>⌂ Início</b><span>▣ Escolas</span><span>✉ Publicações</span><span>▧ Arquivos</span><span>⚙ Configurações</span></nav></aside><section className="admin-center">
      <article className="admin-welcome"><small>INÍCIO &gt; PERFIL DA ASSESSORIA</small><h1>Olá, {settings.assessorName}! 😊</h1><p>Gerencie sua rede, abra o perfil de cada escola e edite todos os conteúdos da assessoria.</p><div><span><b>{access.schools.length}</b> escolas</span><span><b>ADM</b> acesso total</span><span><b>24h</b> portal ativo</span></div></article>
      <section className="create-school">
        <form onSubmit={onCreate}><label>Nome da escola<input value={schoolName} onChange={(event) => setSchoolName(event.target.value)} placeholder="Ex.: Escola Cassiano" /></label><button>Criar portal</button></form>
        {codeSchool ? <div className="created-code"><span>CÓDIGO DE {codeSchool.name}</span>{createdCode ? <><strong>{createdCode}</strong><button onClick={() => navigator.clipboard.writeText(createdCode)}>Copiar código</button></> : <small>Código anterior protegido. Use “Novo código” apenas uma vez para ele ficar disponível aqui.</small>}</div> : null}
      </section>
      <section className="school-grid">
        {access.schools.map((school) => <article key={school.id} onClick={() => onShowCode(school)}><div className="folder-icon">▰</div><div><small>ESCOLA ASSESSORADA</small><h2>{school.name}</h2><p>Agenda, trabalhos, materiais e comunicação exclusivos.</p></div><button onClick={(event) => { event.stopPropagation(); onOpen(school); }}>Abrir portal</button><button className="secondary" onClick={(event) => { event.stopPropagation(); onReset(school); }}>Novo código</button></article>)}
        {!access.schools.length ? <div className="empty-state">Cadastre a primeira escola para começar.</div> : null}
      </section></section><aside className="admin-right"><h3>Minha rede</h3><p><b>{access.schools.length}</b> escolas assessoradas</p><p>Entre em uma escola para publicar, anexar, editar ou excluir.</p><button onClick={onEditSettings}>Personalizar portal</button></aside></div>
    </main>
  );
}

function SettingsEditor({ settings, onClose, onSave }: { settings: Settings; onClose: () => void; onSave: (settings: Settings) => void }) {
  return <div className="modal-backdrop"><section className="composer settings-editor"><header><div><span>MODO DE EDIÇÃO GERAL</span><h2>Personalizar portal</h2></div><button onClick={onClose}>×</button></header><form onSubmit={(event) => { event.preventDefault(); const data = new FormData(event.currentTarget); onSave(Object.fromEntries(data) as unknown as Settings); }}><label>Nome da marca<input name="brandName" defaultValue={settings.brandName} /></label><label>Frase principal<input name="welcomeTitle" defaultValue={settings.welcomeTitle} /></label><label>Texto de apresentação<textarea name="welcomeText" rows={3} defaultValue={settings.welcomeText} /></label><div className="form-row"><label>Nome da assessora<input name="assessorName" defaultValue={settings.assessorName} /></label><label>Cargo/apresentação<input name="assessorTitle" defaultValue={settings.assessorTitle} /></label></div><div className="color-grid"><label>Cor principal<input name="primary" type="color" defaultValue={settings.primary} /></label><label>Rosa<input name="pink" type="color" defaultValue={settings.pink} /></label><label>Amarelo<input name="yellow" type="color" defaultValue={settings.yellow} /></label><label>Fundo<input name="background" type="color" defaultValue={settings.background} /></label></div><button>Salvar tudo</button></form></section></div>;
}

function SchoolEditor({ school, subtitle, onClose, onSave }: { school: School; subtitle: string; onClose: () => void; onSave: (name: string, subtitle: string) => void }) {
  return <div className="modal-backdrop"><section className="composer"><header><div><span>EDITAR PERFIL</span><h2>Dados da escola</h2></div><button onClick={onClose}>×</button></header><form onSubmit={(event) => { event.preventDefault(); const data = new FormData(event.currentTarget); onSave(String(data.get("name")), String(data.get("subtitle"))); }}><label>Nome da escola<input name="name" defaultValue={school.name} required /></label><label>Descrição abaixo do nome<textarea name="subtitle" rows={3} defaultValue={subtitle} required /></label><button>Salvar perfil da escola</button></form></section></div>;
}

function SectionHeader({ section, admin, onAdd }: { section: Section; admin: boolean; onAdd: () => void }) {
  const copy: Record<Section, [string, string]> = {
    inicio: ["Início", "Visão geral do acompanhamento"],
    agenda: ["Agenda", "Compromissos e prazos da assessoria"],
    calendario: ["Calendário", "Organização mensal dos compromissos"],
    trabalhos: ["Trabalhos", "Registros do que estamos construindo juntos"],
    galeria: ["Galeria", "Imagens que contam o percurso da escola"],
    materiais: ["Materiais", "Pastas e arquivos exclusivos da escola"],
    comunicacao: ["Comunicação", "Orientações, recados e devolutivas"],
  };
  const canAdd = admin && !["inicio", "calendario"].includes(section);
  return <header className="section-head"><div><span>{copy[section][1]}</span><h2>{copy[section][0]}</h2></div>{canAdd ? <button onClick={onAdd}>＋ Publicar</button> : null}</header>;
}

function Home({ school, items, admin, onNavigate, onLike, onComment, onEdit, onDelete }: { school: School | null; items: PortalItem[]; admin: boolean; onNavigate: (section: Section) => void; onLike: (item: PortalItem) => void; onComment: CommentHandler; onEdit: (item: PortalItem) => void; onDelete: (item: PortalItem) => void }) {
  const recent = items.filter((item) => ["agenda", "trabalho", "galeria", "orientacao", "recado", "depoimento"].includes(item.kind)).slice(0, 3);
  return (
    <>
      <article className="orkut-home-card"><header>Início &gt; Perfil da escola</header><div><p className="orkut-hello">Olá, {school?.name}!</p><p>Este é o espaço da sua escola na rede POP CHICLÉ PSIEE. Aqui ficam o mural, os recados, as fotos e todo o percurso da assessoria.</p><section><span><b>{items.length}</b> atualizações</span><span><b>{items.reduce((total, item) => total + (item.likes || 0), 0)}</b> curtidas</span><span><b>{items.reduce((total, item) => total + (item.comments?.length || 0), 0)}</b> comentários</span></section></div></article>
      <div className="shortcut-grid">
        {sections.slice(1, 7).map((item) => <button key={item.id} onClick={() => onNavigate(item.id)}><span>{item.icon}</span><b>{item.label}</b><small>Abrir espaço</small></button>)}
      </div>
      <div className="feed-title"><h3>Atualizações recentes</h3></div>
      {recent.length ? <Feed items={recent} empty="" admin={admin} onEdit={onEdit} onDelete={onDelete} onLike={onLike} onComment={onComment} /> : <div className="empty-state">As primeiras atualizações da assessoria aparecerão aqui.</div>}
    </>
  );
}

function ItemActions({ item, onEdit, onDelete }: { item: PortalItem; onEdit: (item: PortalItem) => void; onDelete: (item: PortalItem) => void }) {
  return <div className="item-actions"><button onClick={() => onEdit(item)}>Editar</button><button onClick={() => onDelete(item)}>Excluir</button></div>;
}

function Feed({ items, empty, admin, onEdit, onDelete, onLike, onComment }: { items: PortalItem[]; empty: string; admin: boolean; onEdit: (item: PortalItem) => void; onDelete: (item: PortalItem) => void; onLike: (item: PortalItem) => void; onComment: CommentHandler }) {
  if (!items.length) return <div className="empty-state">{empty}</div>;
  return <div className="feed">{items.map((item) => <article className="post-card" key={item.id}><div className="post-avatar">PC</div><div className="post-body"><header><b>POP CHICLÉ PSIEE</b><span>{new Date(item.createdAt).toLocaleDateString("pt-BR")}</span></header><h3>{item.title}</h3>{item.kind === "trabalho" ? <WorkDetails item={item} /> : <p>{item.content}</p>}{admin ? <ItemActions item={item} onEdit={onEdit} onDelete={onDelete} /> : null}<Engagement item={item} onLike={onLike} onComment={onComment} /></div></article>)}</div>;
}

function WorkDetails({ item }: { item: PortalItem }) {
  return <div className="work-details">{item.content ? <p>{item.content}</p> : null}<div className="work-meta">{item.metadata.workStatus ? <span>{item.metadata.workStatus}</span> : null}{item.metadata.category ? <span>{item.metadata.category}</span> : null}{item.metadata.date ? <span>📅 {new Date(`${item.metadata.date}T12:00:00`).toLocaleDateString("pt-BR")}</span> : null}{item.metadata.responsible ? <span>👤 {item.metadata.responsible}</span> : null}</div><MediaCarousel item={item} />{item.metadata.link ? <a className="work-file" href={item.metadata.link} target="_blank" rel="noreferrer">🔗 Abrir link relacionado</a> : null}</div>;
}

function MediaCarousel({ item }: { item: PortalItem }) {
  const files = item.metadata.files || (item.metadata.key ? [{ key: item.metadata.key, token: item.metadata.token || "", filename: item.metadata.filename || "arquivo", contentType: item.metadata.contentType || "" }] : []);
  const [index, setIndex] = useState(0);
  if (!files.length) return null;
  const safeIndex = Math.min(index, files.length - 1);
  const file = files[safeIndex];
  const url = fileUrl(item, "", safeIndex);
  const pdf = file.contentType === "application/pdf" || file.filename.toLowerCase().endsWith(".pdf");
  return <div className="portal-media-carousel">{file.contentType.startsWith("image/") ? <img src={url} alt={file.filename} /> : file.contentType.startsWith("video/") ? <video src={videoFileUrl(item, "", safeIndex)} controls playsInline preload="auto" /> : pdf ? <><PdfThumbnail url={url} filename={file.filename} /><a className="media-open" href={url} target="_blank" rel="noreferrer">Abrir PDF</a></> : <a className="gallery-file" href={url} target="_blank" rel="noreferrer">📎<b>{file.filename}</b><span>Abrir arquivo</span></a>}{files.length > 1 ? <><button className="carousel-prev" type="button" onClick={() => setIndex((safeIndex - 1 + files.length) % files.length)} aria-label="Arquivo anterior">‹</button><button className="carousel-next" type="button" onClick={() => setIndex((safeIndex + 1) % files.length)} aria-label="Próximo arquivo">›</button><div className="carousel-count">{safeIndex + 1}/{files.length}</div></> : null}</div>;
}

function PdfThumbnail({ url, filename }: { url: string; filename: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    let cancelled = false;
    let destroy: (() => void) | undefined;
    import("pdfjs-dist").then(async (pdfjs) => {
      if (cancelled) return;
      pdfjs.GlobalWorkerOptions.workerSrc = new URL(
        "pdfjs-dist/build/pdf.worker.min.mjs",
        import.meta.url,
      ).toString();
      const task = pdfjs.getDocument({ url, isEvalSupported: false });
      destroy = () => { void task.destroy(); };
      const document = await task.promise;
      const page = await document.getPage(1);
      const original = page.getViewport({ scale: 1 });
      const scale = Math.min(1200 / original.width, 900 / original.height);
      const viewport = page.getViewport({ scale });
      const canvas = canvasRef.current;
      const context = canvas?.getContext("2d");
      if (!canvas || !context || cancelled) return;
      canvas.width = Math.floor(viewport.width);
      canvas.height = Math.floor(viewport.height);
      context.fillStyle = "#fff";
      context.fillRect(0, 0, canvas.width, canvas.height);
      await page.render({ canvas, canvasContext: context, viewport }).promise;
    }).catch(() => {
      if (!cancelled) setFailed(true);
    });
    return () => {
      cancelled = true;
      destroy?.();
    };
  }, [url]);
  return failed ? <div className="pdf-fallback">PDF<br /><small>{filename}</small></div> : <canvas ref={canvasRef} aria-label={`Primeira página de ${filename}`} />;
}

function Engagement({ item, onLike, onComment }: { item: PortalItem; onLike: (item: PortalItem) => void; onComment: CommentHandler }) {
  const [text, setText] = useState("");
  const [author, setAuthor] = useState("");
  const [commentsOpen, setCommentsOpen] = useState(true);
  useEffect(() => {
    setAuthor(window.sessionStorage.getItem("pop_comment_author") || "");
  }, []);
  const commentCount = item.comments?.length || 0;
  return <div className="engagement"><div className="social-actions"><button className={item.liked ? "liked" : ""} onClick={() => onLike(item)}>♥ {item.liked ? "Curtido" : "Curtir"} <span>{item.likes || 0}</span></button><button onClick={() => shareItem(item)}>➤ Compartilhar</button>{commentCount ? <button onClick={() => setCommentsOpen(!commentsOpen)} aria-expanded={commentsOpen}>{commentsOpen ? "▾ Ocultar" : "▸ Ver"} {commentCount} comentário{commentCount === 1 ? "" : "s"}</button> : null}</div>{commentCount && commentsOpen ? <div className="comment-list">{item.comments?.map((comment) => <p key={comment.id}><b>{comment.author}</b>{comment.content}</p>)}</div> : null}<form onSubmit={(event) => { event.preventDefault(); if (text.trim() && author.trim()) { window.sessionStorage.setItem("pop_comment_author", author.trim()); onComment(item, text, author); setText(""); } }}><input className="comment-author" value={author} onChange={(event) => setAuthor(event.target.value)} placeholder="Seu nome" aria-label="Nome de quem comenta" required /><input value={text} onChange={(event) => setText(event.target.value)} placeholder="Escreva um comentário..." aria-label="Comentário" required /><button>Comentar</button></form></div>;
}

function Agenda({ items, admin, onEdit, onDelete }: { items: PortalItem[]; admin: boolean; onEdit: (item: PortalItem) => void; onDelete: (item: PortalItem) => void }) {
  if (!items.length) return <div className="empty-state">Nenhum compromisso publicado ainda.</div>;
  return <div className="agenda-list">{items.map((item) => <article key={item.id} id={`post-${item.id}`}><time>{item.metadata.date ? new Date(`${item.metadata.date}T12:00:00`).toLocaleDateString("pt-BR", { day: "2-digit", month: "short" }) : "A definir"}</time><div><h3>{item.title}</h3><p>{item.content}</p><button className="share-button" onClick={() => shareItem(item)}>➤ Compartilhar</button>{admin ? <ItemActions item={item} onEdit={onEdit} onDelete={onDelete} /> : null}</div></article>)}</div>;
}

function Calendar({ items }: { items: PortalItem[] }) {
  const [month, setMonth] = useState(() => new Date(new Date().getFullYear(), new Date().getMonth(), 1));
  const days = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
  const first = new Date(month.getFullYear(), month.getMonth(), 1).getDay();
  const dated = new Map(items.map((item) => [item.metadata.date, item]));
  return <div className="calendar-card"><header><button onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() - 1, 1))}>‹</button><h3>{month.toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}</h3><button onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1))}>›</button></header><div className="weekdays">{["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"].map((day) => <b key={day}>{day}</b>)}</div><div className="calendar-days">{Array.from({ length: first }).map((_, index) => <span key={`blank-${index}`} />)}{Array.from({ length: days }).map((_, index) => { const day = index + 1; const key = `${month.getFullYear()}-${String(month.getMonth() + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`; const item = dated.get(key); return <div key={day} className={item ? "has-event" : ""}><b>{day}</b>{item ? <small>{item.title}</small> : null}</div>; })}</div></div>;
}

function Gallery({ items, admin, onEdit, onDelete, query, onLike, onComment }: { items: PortalItem[]; admin: boolean; onEdit: (item: PortalItem) => void; onDelete: (item: PortalItem) => void; query: string; onLike: (item: PortalItem) => void; onComment: CommentHandler }) {
  if (!items.length) return <div className="empty-state">Nenhuma imagem publicada ainda.</div>;
  return <div className="gallery-grid">{items.map((item) => <GalleryCard key={item.id} item={item} query={query} admin={admin} onEdit={onEdit} onDelete={onDelete} onLike={onLike} onComment={onComment} />)}</div>;
}

function GalleryCard({ item, query, admin, onEdit, onDelete, onLike, onComment }: { item: PortalItem; query: string; admin: boolean; onEdit: (item: PortalItem) => void; onDelete: (item: PortalItem) => void; onLike: (item: PortalItem) => void; onComment: CommentHandler }) {
  const [index, setIndex] = useState(0);
  const files = item.metadata.files || [{ key: item.metadata.key || "", token: item.metadata.token || "", filename: item.metadata.filename || item.title, contentType: item.metadata.contentType || "image/*" }];
  const file = files[index] || files[0];
  return <figure id={`post-${item.id}`}><div className="gallery-media">{file.contentType.startsWith("video/") ? <video src={videoFileUrl(item, query, index)} controls playsInline preload="auto" /> : file.contentType.startsWith("image/") ? <img src={fileUrl(item, query, index)} alt={`${item.title} — ${index + 1}`} /> : <a className="gallery-file" href={fileUrl(item, query, index)} target="_blank">📎<b>{file.filename}</b><span>Abrir arquivo</span></a>}{files.length > 1 ? <><button className="carousel-prev" onClick={() => setIndex((index - 1 + files.length) % files.length)}>‹</button><button className="carousel-next" onClick={() => setIndex((index + 1) % files.length)}>›</button><div className="carousel-count">{index + 1}/{files.length}</div></> : null}</div><figcaption><b>{item.title}</b>{admin ? <span><button onClick={() => onEdit(item)}>Editar</button><button onClick={() => onDelete(item)}>Excluir</button></span> : null}</figcaption><Engagement item={item} onLike={onLike} onComment={onComment} /></figure>;
}

function Materials({ folders, items, admin, onEdit, onDelete, query }: { folders: PortalItem[]; items: PortalItem[]; admin: boolean; onEdit: (item: PortalItem) => void; onDelete: (item: PortalItem) => void; query: string }) {
  const names = [...new Set([...folders.map((item) => item.title), ...items.map((item) => item.metadata.folder || "Materiais gerais")])];
  if (!names.length) return <div className="empty-state">Nenhuma pasta ou material publicado ainda.</div>;
  return <div className="folder-list">{names.map((name) => {
    const folder = folders.find((item) => item.title === name);
    const files = items.filter((item) => (item.metadata.folder || "Materiais gerais") === name);
    return <details key={name} open><summary><span>▰</span><b>{name}</b><small>{files.length} publicação(ões)</small></summary>{folder?.metadata.link ? <a className="folder-link-button" href={folder.metadata.link} target={folder.metadata.link.startsWith("#") ? undefined : "_blank"} rel="noreferrer">Abrir link da pasta ↗</a> : null}{admin && folder ? <div className="folder-actions"><button onClick={() => onEdit(folder)}>Editar pasta e link</button><button onClick={() => onDelete(folder)}>Excluir pasta</button></div> : null}<div>{files.flatMap((item) => (item.metadata.files || [{ filename: item.title, contentType: item.metadata.contentType || "" } as StoredFile]).map((file, index) => <article key={`${item.id}-${index}`}><span>{file.contentType?.startsWith("video/") ? "🎬" : file.contentType?.startsWith("image/") ? "🖼️" : "📎"}</span><a href={fileUrl(item, query, index)} target="_blank">{file.filename || item.title}</a>{admin && index === 0 ? <button onClick={() => onDelete(item)}>Excluir publicação</button> : null}</article>))}</div></details>;
  })}</div>;
}

function Communication({ items, admin, onApprove, onDelete, onMessage, onLike, onComment }: { items: PortalItem[]; admin: boolean; onApprove: (item: PortalItem) => void; onDelete: (item: PortalItem) => void; onMessage: () => void; onLike: (item: PortalItem) => void; onComment: CommentHandler }) {
  return <><div className="communication-intro"><h3>Comunicação e depoimentos</h3><p>Envie orientações, recados e devolutivas. A escola também pode publicar depoimentos, com aprovação da administradora.</p>{!admin ? <button onClick={onMessage}>Escrever recado ou depoimento</button> : null}</div><div className="feed">{items.map((item) => <article id={`post-${item.id}`} className={`post-card${item.metadata.status === "pendente" ? " pending" : ""}${item.kind === "depoimento" ? " testimonial" : ""}`} key={item.id}><div className="post-avatar">{item.kind === "depoimento" ? "♥" : item.kind === "recado" ? "E" : "PC"}</div><div className="post-body"><header><b>{item.kind === "orientacao" ? "POP CHICLÉ PSIEE" : item.title}</b><span>{item.metadata.status === "pendente" ? "Aguardando aprovação" : new Date(item.createdAt).toLocaleDateString("pt-BR")}</span></header><h3>{item.kind === "depoimento" ? "Depoimento" : item.kind === "orientacao" ? item.title : item.metadata.role || "Equipe escolar"}</h3><div className="work-meta">{item.kind === "depoimento" ? <span>♥ Depoimento da escola</span> : null}{item.metadata.priority ? <span>{item.metadata.priority}</span> : null}{item.metadata.audience ? <span>Para: {item.metadata.audience}</span> : null}{item.metadata.date ? <span>📅 {new Date(`${item.metadata.date}T12:00:00`).toLocaleDateString("pt-BR")}</span> : null}</div><p>{item.content}</p><Attachments item={item} />{item.metadata.link ? <a className="work-file" href={item.metadata.link} target="_blank" rel="noreferrer">🔗 Abrir link</a> : null}{admin ? <div className="item-actions">{item.metadata.status === "pendente" ? <button onClick={() => onApprove(item)}>Aprovar</button> : null}<button onClick={() => onDelete(item)}>Excluir</button></div> : null}<Engagement item={item} onLike={onLike} onComment={onComment} /></div></article>)}</div></>;
}

function Attachments({ item }: { item: PortalItem }) {
  return <MediaCarousel item={item} />;
}

function Composer({ section, admin, editing, onClose, onSaveText, onSaveFile, onSaveWork, onSaveCommunication }: { section: Section; admin: boolean; editing: PortalItem | null; onClose: () => void; onSaveText: (event: FormEvent<HTMLFormElement>) => void; onSaveFile: (event: FormEvent<HTMLFormElement>) => void; onSaveWork: (event: FormEvent<HTMLFormElement>) => void; onSaveCommunication: (event: FormEvent<HTMLFormElement>) => void }) {
  const allFiles = "image/*,video/*,.pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt,.zip";
  const kind = !admin ? "recado" : section === "trabalhos" ? "trabalho" : section === "comunicacao" ? "orientacao" : section === "materiais" ? "material" : section;
  let form;
  if (section === "trabalhos" && admin) {
    form = <form onSubmit={onSaveWork}><input type="hidden" name="kind" value="trabalho" /><label>Título do trabalho<input name="title" required defaultValue={editing?.title} /></label><label>Descrição completa<textarea name="content" rows={5} required defaultValue={editing?.content} /></label><div className="form-row"><label>Data<input name="date" type="date" defaultValue={editing?.metadata.date} /></label><label>Status<select name="workStatus" defaultValue={editing?.metadata.workStatus || "Em andamento"}><option>Planejado</option><option>Em andamento</option><option>Concluído</option><option>Aguardando devolutiva</option></select></label></div><div className="form-row"><label>Categoria<input name="category" defaultValue={editing?.metadata.category} /></label><label>Responsável<input name="responsible" defaultValue={editing?.metadata.responsible} /></label></div><label>Link relacionado<input name="link" type="url" defaultValue={editing?.metadata.link} /></label>{!editing ? <UploadField label="Até 10 fotos, vídeos ou arquivos — máximo de 1 GB no total" accept={allFiles} /> : null}<button>{editing ? "Salvar alterações" : "Publicar trabalho"}</button></form>;
  } else if (section === "comunicacao") {
    form = <form onSubmit={onSaveCommunication}><label>Tipo de publicação<select name="kind" defaultValue={editing?.kind || (admin ? "orientacao" : "recado")}>{admin ? <><option value="orientacao">Comunicação da assessoria</option><option value="depoimento">Depoimento publicado pela assessoria</option></> : <><option value="recado">Recado para a assessoria</option><option value="depoimento">Depoimento sobre a assessoria</option></>}</select></label><label>{admin ? "Título ou autoria" : "Seu nome"}<input name="title" required defaultValue={editing?.title} /></label><label>Texto da publicação<textarea name="content" rows={6} required defaultValue={editing?.content} /></label><div className="form-row"><label>Data<input name="date" type="date" defaultValue={editing?.metadata.date} /></label><label>Prioridade<select name="priority" defaultValue={editing?.metadata.priority || "Normal"}><option>Normal</option><option>Importante</option><option>Urgente</option></select></label></div><label>Destinatário<input name="audience" defaultValue={editing?.metadata.audience || "Equipe escolar"} /></label><label>Link opcional<input name="link" type="url" defaultValue={editing?.metadata.link} /></label>{!editing ? <UploadField label="Até 10 arquivos, incluindo PNG, JPG, vídeos e documentos — máximo de 1 GB no total" accept={allFiles} /> : null}{!admin ? <label>Função na escola<input name="role" /></label> : null}<button>{editing ? "Salvar alterações" : "Enviar publicação"}</button></form>;
  } else if (section === "materiais" && admin && editing?.kind === "pasta") {
    form = <form onSubmit={onSaveText}><input type="hidden" name="kind" value="pasta" /><label>Nome da pasta<input name="title" required defaultValue={editing.title} /></label><label>Link da pasta<input name="link" defaultValue={editing.metadata.link} /></label><button>Salvar pasta</button></form>;
  } else if (section === "materiais" && admin) {
    form = <><form onSubmit={onSaveText}><input type="hidden" name="kind" value="pasta" /><label>Nome da nova pasta<input name="title" required /></label><label>Link da pasta — opcional<input name="link" /></label><button>Criar pasta</button></form><div className="composer-divider"><span>OU ADICIONE CONTEÚDOS</span></div><form onSubmit={onSaveFile}><input type="hidden" name="kind" value="material" /><label>Título<input name="title" required /></label><label>Pasta<input name="folder" /></label><UploadField label="Até 10 fotos, vídeos ou arquivos — máximo de 1 GB no total" accept={allFiles} required /><button>Publicar materiais</button></form></>;
  } else if (section === "galeria" && editing) {
    form = <form onSubmit={onSaveText}><input type="hidden" name="kind" value="galeria" /><label>Título da postagem<input name="title" required defaultValue={editing.title} /></label><label>Legenda<textarea name="content" rows={4} defaultValue={editing.content} /></label><button>Salvar alterações</button></form>;
  } else if (section === "galeria" && admin) {
    form = <form onSubmit={onSaveFile}><input type="hidden" name="kind" value="galeria" /><label>Título<input name="title" required /></label><label>Legenda<textarea name="content" rows={4} /></label><UploadField label="Carrossel com até 10 fotos ou vídeos — máximo de 1 GB no total" accept="image/*,video/*" required /><button>Publicar na galeria</button></form>;
  } else {
    form = <form onSubmit={onSaveText}><input type="hidden" name="kind" value={kind} /><label>Título<input name="title" required defaultValue={editing?.title} /></label>{section === "agenda" ? <label>Data<input name="date" type="date" defaultValue={editing?.metadata.date} /></label> : null}<label>Descrição<textarea name="content" rows={6} required defaultValue={editing?.content} /></label><button>{editing ? "Salvar alterações" : "Publicar"}</button></form>;
  }
  return <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><section className="composer"><header><div><span>{editing ? "EDITAR PUBLICAÇÃO" : "NOVA PUBLICAÇÃO"}</span><h2>{sections.find((item) => item.id === section)?.label}</h2></div><button onClick={onClose}>×</button></header>{form}</section></div>;
}

function UploadField({ label, accept, required = false }: { label: string; accept: string; required?: boolean }) {
  const [selectedNames, setSelectedNames] = useState<string[]>([]);
  return <label className="upload-field">{label}<input name="files" type="file" multiple required={required} accept={accept} onChange={(event) => setSelectedNames(Array.from(event.currentTarget.files || []).map((file) => file.name))} />{selectedNames.length ? <div className="selected-files"><b>✓ {selectedNames.length} arquivo{selectedNames.length === 1 ? "" : "s"} selecionado{selectedNames.length === 1 ? "" : "s"}</b>{selectedNames.map((name) => <span key={name}>{name}</span>)}</div> : <small>Selecione até 10 fotos, vídeos ou arquivos de uma vez.</small>}</label>;
}
