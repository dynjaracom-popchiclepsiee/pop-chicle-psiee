import { sql } from "drizzle-orm";
import { index, integer, pgTable, serial, text, uniqueIndex } from "drizzle-orm/pg-core";

export const portalSettings = pgTable("portal_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const portalItems = pgTable("portal_items", {
  id: serial("id").primaryKey(),
  schoolId: text("school_id").notNull().default("default"),
  kind: text("kind").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull().default(""),
  metadata: text("metadata").notNull().default("{}"),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  index("portal_items_school_kind_idx").on(table.schoolId, table.kind),
]);

export const portalSchools = pgTable("portal_schools", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  userEmail: text("user_email").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (table) => [
  uniqueIndex("portal_schools_user_email_idx").on(table.userEmail),
]);

export const schools = pgTable("schools", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  codeHash: text("code_hash").notNull().unique(),
  accessCode: text("access_code"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const schoolSessions = pgTable("school_sessions", {
  token: text("token").primaryKey(),
  schoolId: text("school_id").notNull(),
  expiresAt: text("expires_at").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const schoolPortals = pgTable("school_portals", {
  schoolId: text("school_id").primaryKey(),
  dataJson: text("data_json").notNull().default("{}"),
  htmlKey: text("html_key"),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});
