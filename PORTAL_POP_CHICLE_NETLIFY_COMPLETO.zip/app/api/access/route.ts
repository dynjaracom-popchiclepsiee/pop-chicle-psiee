import { desc, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { portalItems, schoolSessions, schools } from "../../../db/schema";
import {
  getSchoolSession,
  ADMIN_COOKIE,
  isAdminRequest,
  newSchoolCode,
  readCookie,
  SESSION_COOKIE,
  sha256,
} from "../school-auth";

export const dynamic = "force-dynamic";

function cookie(token: string, maxAge: number) {
  return `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;
}

function adminCookie(token: string, maxAge: number) {
  return `${ADMIN_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;
}

function withCookies(...values: string[]) {
  const headers = new Headers();
  for (const value of values) headers.append("set-cookie", value);
  return headers;
}

export async function GET(request: Request) {
  if (new URL(request.url).searchParams.get("entry") === "1") {
    return Response.json({ role: "guest" });
  }
  const db = await getDb();
  if (await isAdminRequest(request)) {
    const list = await db.select({ id: schools.id, name: schools.name, code: schools.accessCode, createdAt: schools.createdAt }).from(schools).orderBy(desc(schools.createdAt));
    return Response.json({ role: "admin", schools: list });
  }
  const school = await getSchoolSession(request);
  if (school) return Response.json({ role: "school", school: { id: school.id, name: school.name } });
  return Response.json({ role: "guest" });
}

export async function POST(request: Request) {
  const body = (await request.json()) as { action?: string; name?: string; subtitle?: string; code?: string; schoolId?: string; username?: string; password?: string };
  const db = await getDb();

  if (body.action === "admin-login") {
    if (body.username !== process.env.ADMIN_USERNAME || body.password !== process.env.ADMIN_PASSWORD) {
      return Response.json({ error: "Usuário ou senha incorretos." }, { status: 401 });
    }
    return Response.json(
      { ok: true },
      { headers: withCookies(adminCookie(process.env.ADMIN_SESSION_TOKEN || "", 30 * 24 * 60 * 60), cookie("", 0)) },
    );
  }

  if (body.action === "create-school") {
    if (!(await isAdminRequest(request))) return Response.json({ error: "Acesso administrativo necessário." }, { status: 403 });
    const name = body.name?.trim();
    if (!name) return Response.json({ error: "Informe o nome da escola." }, { status: 400 });
    const code = newSchoolCode();
    const school = { id: crypto.randomUUID(), name, codeHash: await sha256(code), accessCode: code };
    await db.insert(schools).values(school);
    await db.insert(portalItems).values([
      {
        schoolId: school.id,
        kind: "trabalho",
        title: "Acolhimento e retomada",
        content: "Apresentação da nova fase da assessoria, organização dos canais de comunicação e definição das prioridades iniciais.",
        metadata: JSON.stringify({ status: "publicado" }),
        sortOrder: 3,
      },
      {
        schoolId: school.id,
        kind: "trabalho",
        title: "Leitura institucional",
        content: "Levantamento das demandas, barreiras, potencialidades, rotinas e necessidades da equipe escolar.",
        metadata: JSON.stringify({ status: "publicado" }),
        sortOrder: 2,
      },
      {
        schoolId: school.id,
        kind: "orientacao",
        title: "Bem-vindos ao portal",
        content: "Este espaço será utilizado para organizar a agenda, registrar as ações, disponibilizar materiais e manter a comunicação com a equipe escolar.",
        metadata: JSON.stringify({ status: "publicado" }),
        sortOrder: 1,
      },
    ]);
    return Response.json({ school: { id: school.id, name }, code }, { status: 201 });
  }

  if (body.action === "reset-code") {
    if (!(await isAdminRequest(request))) return Response.json({ error: "Acesso administrativo necessário." }, { status: 403 });
    const schoolId = body.schoolId?.trim();
    if (!schoolId) return Response.json({ error: "Escola não informada." }, { status: 400 });
    const code = newSchoolCode();
    await db.update(schools).set({ codeHash: await sha256(code), accessCode: code, updatedAt: new Date().toISOString() }).where(eq(schools.id, schoolId));
    return Response.json({ code });
  }

  if (body.action === "remember-code") {
    if (!(await isAdminRequest(request))) return Response.json({ error: "Acesso administrativo necessário." }, { status: 403 });
    const schoolId = body.schoolId?.trim();
    const code = body.code?.trim().toUpperCase();
    if (!schoolId || !code) return Response.json({ error: "Código não informado." }, { status: 400 });
    const [school] = await db.select({ codeHash: schools.codeHash }).from(schools).where(eq(schools.id, schoolId)).limit(1);
    if (!school || school.codeHash !== await sha256(code)) return Response.json({ error: "Este não é o código atual da escola." }, { status: 400 });
    await db.update(schools).set({ accessCode: code, updatedAt: new Date().toISOString() }).where(eq(schools.id, schoolId));
    return Response.json({ code, ok: true });
  }

  if (body.action === "update-school") {
    if (!(await isAdminRequest(request))) return Response.json({ error: "Acesso administrativo necessário." }, { status: 403 });
    const schoolId = body.schoolId?.trim();
    const name = body.name?.trim();
    const subtitle = String((body as { subtitle?: string }).subtitle || "").trim();
    if (!schoolId || !name) return Response.json({ error: "Informe o nome da escola." }, { status: 400 });
    await db.update(schools).set({ name, updatedAt: new Date().toISOString() }).where(eq(schools.id, schoolId));
    const configRows = await db.select().from(portalItems).where(eq(portalItems.schoolId, schoolId));
    const config = configRows.find((item) => item.kind === "config");
    if (config) {
      await db.update(portalItems).set({ content: subtitle, updatedAt: new Date().toISOString() }).where(eq(portalItems.id, config.id));
    } else {
      await db.insert(portalItems).values({ schoolId, kind: "config", title: "Perfil da escola", content: subtitle, metadata: "{}", sortOrder: 0 });
    }
    return Response.json({ school: { id: schoolId, name }, subtitle, ok: true });
  }

  if (body.action === "login") {
    const codeHash = await sha256(body.code ?? "");
    const [school] = await db.select({ id: schools.id, name: schools.name }).from(schools).where(eq(schools.codeHash, codeHash)).limit(1);
    if (!school) return Response.json({ error: "Código da escola inválido." }, { status: 401 });
    const token = crypto.randomUUID() + crypto.randomUUID();
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
    await db.insert(schoolSessions).values({ token, schoolId: school.id, expiresAt });
    return Response.json(
      { role: "school", school },
      { headers: withCookies(cookie(token, 30 * 24 * 60 * 60), adminCookie("", 0)) },
    );
  }

  if (body.action === "logout") {
    const token = readCookie(request, SESSION_COOKIE);
    if (token) await db.delete(schoolSessions).where(eq(schoolSessions.token, token));
    return Response.json({ ok: true }, { headers: withCookies(cookie("", 0), adminCookie("", 0)) });
  }

  return Response.json({ error: "Ação inválida." }, { status: 400 });
}
