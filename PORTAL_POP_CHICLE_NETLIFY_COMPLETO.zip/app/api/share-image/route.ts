import { and, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { portalItems } from "../../../db/schema";
import { downloadFile } from "../../../lib/storage";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const id = Number(url.searchParams.get("id"));
  const token = url.searchParams.get("token") || "";
  if (!Number.isInteger(id) || id < 1 || !token) {
    return new Response("Miniatura não encontrada.", { status: 404 });
  }

  const db = await getDb();
  const [item] = await db.select().from(portalItems).where(eq(portalItems.id, id)).limit(1);
  if (!item) return new Response("Miniatura não encontrada.", { status: 404 });

  const metadata = JSON.parse(item.metadata || "{}");
  if (metadata.shareToken !== token) return new Response("Miniatura não encontrada.", { status: 404 });

  let mediaMetadata = metadata;
  let file = mediaMetadata.files?.find((entry: { contentType?: string }) => entry.contentType?.startsWith("image/"))
    || (mediaMetadata.contentType?.startsWith("image/") ? mediaMetadata : null);
  if (!file) {
    const [profile] = await db.select().from(portalItems)
      .where(and(eq(portalItems.schoolId, item.schoolId), eq(portalItems.kind, "perfil"))).limit(1);
    if (profile) {
      mediaMetadata = JSON.parse(profile.metadata || "{}");
      file = mediaMetadata.files?.find((entry: { contentType?: string }) => entry.contentType?.startsWith("image/"))
        || (mediaMetadata.contentType?.startsWith("image/") ? mediaMetadata : null);
    }
  }
  if (!file?.key) return new Response("Miniatura não encontrada.", { status: 404 });

  const object = await downloadFile(file.key);
  if (!object) return new Response("Miniatura não encontrada.", { status: 404 });

  return new Response(object, {
    headers: {
      "content-type": file.contentType || "image/jpeg",
      "content-length": String(object.size),
      "cache-control": "public, max-age=86400",
    },
  });
}
