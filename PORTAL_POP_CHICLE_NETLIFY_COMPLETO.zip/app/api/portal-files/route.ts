import { and, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { portalItems, schools } from "../../../db/schema";
import { isAdminRequest, resolveSchoolId } from "../school-auth";
import { deleteFile, downloadFile, uploadFile } from "../../../lib/storage";

export const dynamic = "force-dynamic";

async function context(request: Request) {
  const schoolId = await resolveSchoolId(request);
  if (!schoolId) return null;
  const db = await getDb();
  const [school] = await db.select({ id: schools.id, name: schools.name }).from(schools).where(eq(schools.id, schoolId)).limit(1);
  return school ? { db, school, admin: await isAdminRequest(request) } : null;
}

export async function POST(request: Request) {
  const ctx = await context(request);
  if (!ctx) return Response.json({ error: "Acesso necessário." }, { status: 401 });
  const data = await request.formData();
  const kind = String(data.get("kind") || "");
  const title = String(data.get("title") || "").trim();
  const folder = String(data.get("folder") || "").trim();
  const content = String(data.get("content") || "").trim();
  const multiple = data.getAll("files").filter((entry): entry is File => entry instanceof File && entry.size > 0);
  const single = data.get("file");
  const files = multiple.length ? multiple : single instanceof File && single.size > 0 ? [single] : [];
  if (!["galeria", "material", "perfil", "trabalho", "orientacao", "recado", "depoimento"].includes(kind) || !files.length) {
    return Response.json({ error: "Selecione pelo menos um arquivo válido." }, { status: 400 });
  }
  if (!ctx.admin && !["recado", "depoimento"].includes(kind)) return Response.json({ error: "Acesso administrativo necessário." }, { status: 403 });
  if (files.length > 10) return Response.json({ error: "Envie no máximo 10 arquivos por publicação." }, { status: 400 });
  if (kind === "perfil" && !files[0].type.startsWith("image/")) {
    return Response.json({ error: "A foto da escola precisa ser uma imagem." }, { status: 400 });
  }
  const totalSize = files.reduce((sum, file) => sum + file.size, 0);
  if (files.some((file) => file.size > 1024 * 1024 * 1024) || totalSize > 1024 * 1024 * 1024) {
    return Response.json({ error: "A publicação pode ter até 1 GB no total." }, { status: 413 });
  }
  const storedFiles = [];
  for (const file of files) {
    const id = crypto.randomUUID();
    const key = `${ctx.school.id}/${id}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
    await uploadFile(key, await file.arrayBuffer(), file.type || "application/octet-stream");
    storedFiles.push({ key, token: crypto.randomUUID(), filename: file.name, contentType: file.type || "application/octet-stream", size: file.size });
  }
  const first = storedFiles[0];
  const metadata = {
    ...first, files: storedFiles, folder,
    date: String(data.get("date") || ""), category: String(data.get("category") || ""),
    responsible: String(data.get("responsible") || ""), link: String(data.get("link") || ""),
    workStatus: String(data.get("workStatus") || "Em andamento"),
    audience: String(data.get("audience") || "Equipe escolar"),
    priority: String(data.get("priority") || "Normal"),
    status: ctx.admin ? "publicado" : "pendente",
  };
  if (kind === "perfil") {
    const previous = await ctx.db
      .select()
      .from(portalItems)
      .where(and(eq(portalItems.schoolId, ctx.school.id), eq(portalItems.kind, "perfil")));
    for (const item of previous) {
      const old = JSON.parse(item.metadata || "{}") as { key?: string; files?: Array<{ key: string }> };
      for (const stored of old.files || (old.key ? [{ key: old.key }] : [])) await deleteFile(stored.key);
    }
    await ctx.db.delete(portalItems).where(and(eq(portalItems.schoolId, ctx.school.id), eq(portalItems.kind, "perfil")));
  }
  if (kind === "material" && folder) {
    const [existingFolder] = await ctx.db
      .select({ id: portalItems.id })
      .from(portalItems)
      .where(and(eq(portalItems.schoolId, ctx.school.id), eq(portalItems.kind, "pasta"), eq(portalItems.title, folder)))
      .limit(1);
    if (!existingFolder) {
      await ctx.db.insert(portalItems).values({
        schoolId: ctx.school.id,
        kind: "pasta",
        title: folder,
        content: "",
        metadata: JSON.stringify({ status: "publicado", link: "" }),
        sortOrder: Date.now(),
      });
    }
  }
  const [created] = await ctx.db
    .insert(portalItems)
    .values({
      schoolId: ctx.school.id,
      kind,
      title: title || files[0].name,
      content,
      metadata: JSON.stringify(metadata),
      sortOrder: Date.now(),
    })
    .returning();
  return Response.json({ item: { ...created, metadata } }, { status: 201 });
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const id = Number(url.searchParams.get("id"));
  const index = Math.max(0, Number(url.searchParams.get("index") || 0));
  const token = url.searchParams.get("token") || "";
  const db = await getDb();
  const [item] = await db
    .select()
    .from(portalItems)
    .where(eq(portalItems.id, id))
    .limit(1);
  if (!item) return new Response("Arquivo não encontrado.", { status: 404 });
  const metadata = JSON.parse(item.metadata || "{}") as { key?: string; token?: string; filename?: string; contentType?: string; files?: Array<{ key: string; token: string; filename: string; contentType: string }> };
  const selected = metadata.files?.[index] || metadata;
  if (!selected.token || token !== selected.token) {
    const ctx = await context(request);
    if (!ctx || ctx.school.id !== item.schoolId) return new Response("Acesso necessário.", { status: 401 });
  }
  if (!selected.key) return new Response("Arquivo não encontrado.", { status: 404 });
  const object = await downloadFile(selected.key);
  if (!object) return new Response("Arquivo não encontrado.", { status: 404 });
  return new Response(object, {
    headers: {
      "content-type": selected.contentType || "application/octet-stream",
      "content-disposition": `inline; filename="${(selected.filename || "arquivo").replace(/"/g, "")}"`,
      "cache-control": "public, max-age=3600",
    },
  });
}
