import { and, eq, gt } from "drizzle-orm";
import { getDb } from "../../db";
import { schoolSessions, schools } from "../../db/schema";

export const SESSION_COOKIE = "pop_school_session";
export const ADMIN_COOKIE = "pop_admin_session";

export async function isAdminRequest(request: Request) {
  const hostname = new URL(request.url).hostname;
  if (hostname === "terminal.local" || hostname === "localhost") return true;
  const token = readCookie(request, ADMIN_COOKIE);
  return Boolean(token && process.env.ADMIN_SESSION_TOKEN && token === process.env.ADMIN_SESSION_TOKEN);
}

export function readCookie(request: Request, name: string) {
  const cookies = request.headers.get("cookie") ?? "";
  for (const part of cookies.split(";")) {
    const [key, ...value] = part.trim().split("=");
    if (key === name) return decodeURIComponent(value.join("="));
  }
  return "";
}

export async function sha256(value: string) {
  const bytes = new TextEncoder().encode(value.trim().toUpperCase());
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

export function newSchoolCode() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = crypto.getRandomValues(new Uint8Array(7));
  const suffix = [...bytes].map((byte) => alphabet[byte % alphabet.length]).join("");
  return `POP-${suffix}`;
}

export async function getSchoolSession(request: Request) {
  const token = readCookie(request, SESSION_COOKIE);
  if (!token) return null;
  const db = await getDb();
  const [result] = await db
    .select({
      id: schools.id,
      name: schools.name,
      expiresAt: schoolSessions.expiresAt,
    })
    .from(schoolSessions)
    .innerJoin(schools, eq(schools.id, schoolSessions.schoolId))
    .where(and(eq(schoolSessions.token, token), gt(schoolSessions.expiresAt, new Date().toISOString())))
    .limit(1);
  return result ?? null;
}

export async function resolveSchoolId(request: Request) {
  const url = new URL(request.url);
  if (await isAdminRequest(request)) {
    const selected = url.searchParams.get("schoolId")?.trim();
    return selected || null;
  }
  return (await getSchoolSession(request))?.id ?? null;
}
