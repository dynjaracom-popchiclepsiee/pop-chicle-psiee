create table if not exists portal_settings (
  key text primary key,
  value text not null,
  updated_at text not null default current_timestamp::text
);

create table if not exists portal_items (
  id serial primary key,
  school_id text not null default 'default',
  kind text not null,
  title text not null,
  content text not null default '',
  metadata text not null default '{}',
  sort_order integer not null default 0,
  created_at text not null default current_timestamp::text,
  updated_at text not null default current_timestamp::text
);
create index if not exists portal_items_school_kind_idx on portal_items (school_id, kind);

create table if not exists portal_schools (
  id text primary key,
  name text not null,
  user_email text not null unique,
  created_at text not null default current_timestamp::text
);

create table if not exists schools (
  id text primary key,
  name text not null,
  code_hash text not null unique,
  access_code text,
  created_at text not null default current_timestamp::text,
  updated_at text not null default current_timestamp::text
);

create table if not exists school_sessions (
  token text primary key,
  school_id text not null,
  expires_at text not null,
  created_at text not null default current_timestamp::text
);

create table if not exists school_portals (
  school_id text primary key,
  data_json text not null default '{}',
  html_key text,
  updated_at text not null default current_timestamp::text
);

insert into storage.buckets (id, name, public, file_size_limit)
values ('school-files', 'school-files', false, 1073741824)
on conflict (id) do update set file_size_limit = 1073741824;
